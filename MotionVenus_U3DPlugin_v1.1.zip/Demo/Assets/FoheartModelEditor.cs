﻿using System.Collections;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(FoheartMC.FoheartModelNormal))]
public class FOHEART_ModelEditor : Editor 
{
    SerializedProperty transformsField;

    public override void OnInspectorGUI()
    {
        FoheartMC.FoheartModelNormal script = (FoheartMC.FoheartModelNormal)target;
        //default
        DrawDefaultInspector();
        if (GUILayout.Button("Self-binding bones"))
        {
            Debug.Log("load transforms references into bones list!");
            
            script.initNameAndBone();
            EditorUtility.SetDirty(script);
            UnityEditor.SceneManagement.EditorSceneManager.MarkAllScenesDirty();
        }

        serializedObject.Update();
        transformsField = serializedObject.FindProperty("transforms");
        EditorGUILayout.PropertyField(serializedObject.FindProperty("transforms"), new GUIContent("transforms"), true);

        EditorGUI.indentLevel += 1;
        for (int i = 0; i < transformsField.arraySize; i++)
        {
            EditorGUILayout.PropertyField(transformsField.GetArrayElementAtIndex(i), new GUIContent(((FoheartMC.FoheartModelNormal.FoheartBones)i).ToString()));
        }
        EditorGUI.indentLevel -= 1;
        serializedObject.ApplyModifiedProperties();

    }
}