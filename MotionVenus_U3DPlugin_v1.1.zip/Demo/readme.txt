1. Unity3D version required 2018.4.8f1（64Bit）.
2. Need to pre-install .Net Framework 4.7.1 runtime, download from https://dotnet.microsoft.com/download/dotnet-framework/net471.